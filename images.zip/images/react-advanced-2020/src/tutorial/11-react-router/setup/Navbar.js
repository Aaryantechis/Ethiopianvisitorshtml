import React from 'react';
import { Link } from 'react-router-dom';
const Navbar = () => {
  return <nav>navbar</nav>;
};

export default Navbar;
