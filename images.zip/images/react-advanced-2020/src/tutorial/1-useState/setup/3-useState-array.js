import React from 'react';
import { data } from '../../../data';

const UseStateArray = () => {
  return <h2>useState array example</h2>;
};

export default UseStateArray;
