import React, { useState } from 'react';

const UseStateBasics = () => {
  return <h2>useState basic example</h2>;
};

export default UseStateBasics;
