import React, { useState } from 'react';

// more components
// fix - context api, redux (for more complex cases)

const PropDrilling = () => {
  return <h2>prop drilling</h2>;
};

export default PropDrilling;
